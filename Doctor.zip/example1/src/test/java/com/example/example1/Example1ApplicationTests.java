package com.example.example1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Example1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
