package com.example.example1.service;

import com.example.example1.model.Doctor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;

@Service
 public class DoctorServiceImpI  implements DoctorService {

    ArrayList<Doctor> doctors = new ArrayList<>(Arrays .asList(
            new Doctor(1,"Ahmad","Ahmad@gmail.com","Nablus","0568123456") ,
            new Doctor(2,"Ali","Ali@gmail.com","Ramallah","0598223477"),
            new Doctor(3,"Sameer","Sameer@gmail.com","Jenin","05634523459"),
            new Doctor(4,"Mira","Miraad@gmail.com","Jericho","05636788996"),
            new Doctor(5,"Sally","Sally@gmail.com","USA","0545768987")


    ));


    // Method to update a user in the ArrayList

    // Method to update a user in the ArrayList
    public void updateUser(Doctor  updatedUser) {
        int index = -1;
        for (int i = 0; i < doctors.size(); i++) {
            Doctor user = doctors.get(i);
            if (user.getDoctorID()==(updatedUser.getDoctorID() )) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            doctors.set(index, updatedUser);
        }
    }


    public ArrayList <Doctor>getAllDoctors() {
        return doctors;
    }


    public Doctor  getDoctorByID(int DoctorID) {
        for (Doctor doctor : doctors) {
            if (doctor.getDoctorID() == DoctorID) {
                return doctor;
            }
        }

        return null;
    }

        public void insertDoctor(Doctor doc) {
            doctors.add(doc);
        }


    public void deleteUser(int id) {
        doctors .removeIf(doctor -> doctor.getDoctorID()==id);
    }

}
