package com.example.example1.model;

public class Doctor {
     private String Name;
    private int DoctorID;
    private String Email;
    private String Location;
    private  String PhoneNumber ;

    public Doctor(int doctorID,String name, String email, String location, String phoneNumber) {

        DoctorID = doctorID;
        Name = name;
        Email = email;
        Location = location;
        PhoneNumber = phoneNumber;
    }


    public Doctor() {
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getDoctorID() {
        return DoctorID;
    }

    public void setDoctorID(int doctorID) {
        DoctorID = doctorID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }
}