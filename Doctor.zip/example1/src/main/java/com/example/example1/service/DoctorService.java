package com.example.example1.service;

import com.example.example1.model.Doctor;

import java.util.ArrayList;

public interface DoctorService {
    Doctor getDoctorByID(int DoctorID);

     void deleteUser(int id);

     ArrayList<Doctor> getAllDoctors();

     void insertDoctor(Doctor doc);

     void updateUser(Doctor userToUpdate);
}
