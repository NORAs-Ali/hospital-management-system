package com.example.example1.service;

import com.example.example1.model.Doctor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;

@Service
 public class DoctorServiceImpI  implements DoctorService {

    ArrayList<Doctor> doctors = new ArrayList<>(Arrays.asList(
            new Doctor(1, 2, "3 - 10 - 2303", "9:30"),
            new Doctor(2, 4, "11 - 11 - 2303", "10:25"),
            new Doctor(2, 6, "12 - 10 - 2303", "3:30"),
            new Doctor(4, 3, "6 - 7 - 2303", "1:30"),
            new Doctor(5, 2, "18 - 9 - 2303", "10:40")

            ));

    // Method to update a user in the ArrayList

    // Method to update a user in the ArrayList
    public void updateUser(Doctor  updatedUser) {
        int index = -1;
        for (int i = 0; i < doctors.size(); i++) {
            Doctor user = doctors.get(i);
            if (user.getAppointmentID() == (updatedUser.getAppointmentID())) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            doctors.set(index, updatedUser);
        }
    }




    public ArrayList <Doctor>getAllDoctors() {
        return doctors;
    }


    public Doctor  getAppointmentByID(int AppointmentID) {
        for (Doctor doctor : doctors) {
            if (doctor.getAppointmentID() == AppointmentID) {
                return doctor;
            }
        }

        return null;
    }

        public void insertDoctor(Doctor doc) {
            doctors.add(doc);
        }



    public void deleteUser(int id) {
        doctors .removeIf(doctor -> doctor.getAppointmentID()==id);
    }


}
