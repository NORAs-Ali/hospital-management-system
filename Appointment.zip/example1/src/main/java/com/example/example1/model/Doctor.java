package com.example.example1.model;

public class Doctor {
    private int AppointmentID;
    private int DoctorID;
    private String DateofAppointment;
    private String TimeofAppointment;

    public Doctor(int appointmentID, int doctorID, String dateofAppointment, String timeofAppointment) {
        AppointmentID = appointmentID;
        DoctorID = doctorID;
        DateofAppointment = dateofAppointment;
        TimeofAppointment = timeofAppointment;
    }
    public Doctor() {

    }

    public int getAppointmentID() {
        return AppointmentID;
    }

    public void setAppointmentID(int appointmentID) {
        AppointmentID = appointmentID;
    }

    public int getDoctorID() {
        return DoctorID;
    }

    public void setDoctorID(int doctorID) {
        DoctorID = doctorID;
    }

    public String getDateofAppointment() {
        return DateofAppointment;
    }

    public void setDateofAppointment(String dateofAppointment) {
        DateofAppointment = dateofAppointment;
    }

    public String getTimeofAppointment() {
        return TimeofAppointment;
    }

    public void setTimeofAppointment(String timeofAppointment) {
        TimeofAppointment = timeofAppointment;
    }
}