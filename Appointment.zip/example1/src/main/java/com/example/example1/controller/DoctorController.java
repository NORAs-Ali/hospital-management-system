package com.example.example1.controller;
import com.example.example1.model.Doctor;
import com.example.example1.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
public class DoctorController {
    DoctorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }
    @RequestMapping("/AllAppointment")

    @GetMapping
    public ArrayList<Doctor>getAllDoctors(){
        return doctorService.getAllDoctors();
    }
    @PutMapping("/updates")
    public void updateUser(@PathVariable int AppointmentID , @RequestBody Doctor  updatedUser) {
        Doctor  userToUpdate = new Doctor();
        userToUpdate.setAppointmentID(AppointmentID) ;
        userToUpdate.setDoctorID(updatedUser.getDoctorID());
        userToUpdate.setDateofAppointment(updatedUser.getDateofAppointment());
        userToUpdate.setTimeofAppointment(updatedUser. getTimeofAppointment());

        doctorService.updateUser(userToUpdate);
    }




    @GetMapping("/Appointments")

    public Doctor getAppointmentByID(@RequestParam int AppointmentID){
         return doctorService.getAppointmentByID(AppointmentID) ;
    }
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        doctorService.deleteUser(id);
    }
    @PostMapping(value ="save")
    public void insertDoctor(@RequestBody Doctor doc) {
        doctorService.insertDoctor(doc);
    }


}
