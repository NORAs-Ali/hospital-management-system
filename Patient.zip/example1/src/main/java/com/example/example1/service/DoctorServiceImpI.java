package com.example.example1.service;

import com.example.example1.model.Doctor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;

@Service
 public class DoctorServiceImpI  implements DoctorService {

    ArrayList<Doctor> doctors = new ArrayList<>(Arrays .asList(
                     new Doctor("Noor",1,57,"Eget","Female","0567894333"),
                     new Doctor("omar",3,23,"Eget","male","0567894333"),
                     new Doctor("Sameer",4,56,"Ramallah","male","056789433"),
                     new Doctor("Hamza",5, 40,"Nablus","male","05678976532")


            ));


    // Method to update a user in the ArrayList

    // Method to update a user in the ArrayList
    public void updateUser(Doctor  updatedUser) {
        int index = -1;
        for (int i = 0; i < doctors.size(); i++) {
            Doctor user = doctors.get(i);
            if (user.getPatientID()==(updatedUser.getPatientID() )) {
                index = i;
                break;
            }
        }
        if (index != -1) {
            doctors.set(index, updatedUser);
        }
    }


    public ArrayList <Doctor>getAllDoctors() {
        return doctors;
    }


    public Doctor  getPatientByID(int PatientID) {
        for (Doctor doctor : doctors) {
            if (doctor.getPatientID() == PatientID) {
                return doctor;
            }
        }

        return null;
    }

        public void insertDoctor(Doctor doc) {
            doctors.add(doc);
        }




    public void deleteUser(int id) {
        doctors .removeIf(doctor -> doctor.getPatientID()==id);
    }



}
