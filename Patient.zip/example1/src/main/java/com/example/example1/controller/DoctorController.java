package com.example.example1.controller;
import com.example.example1.model.Doctor;
import com.example.example1.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
public class DoctorController {
    octorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }
    @RequestMapping("/AllPatients")

    @GetMapping
    public ArrayList<Doctor>getAllDoctors(){
        return doctorService.getAllDoctors();
    }
    @PutMapping("/updates")
    public void updateUser(@PathVariable int PatientID , @RequestBody Doctor  updatedUser) {
        Doctor  userToUpdate = new Doctor();
        userToUpdate.setPatientID(PatientID) ;
        userToUpdate.setName(updatedUser.getName());
        userToUpdate.setAge(updatedUser.getAge());
        userToUpdate.setAddress(updatedUser.getAddress());
        userToUpdate.setPhoneNumber(updatedUser.getPhoneNumber());
        doctorService.updateUser(userToUpdate);
    }




    @GetMapping("/patient")

    public Doctor getPatientByID(@RequestParam int PatientID){
        return doctorService.getPatientByID(PatientID) ;
    }
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable int id) {
        doctorService.deleteUser(id);
    }
    @PostMapping(value ="save")
    public void insertDoctor(@RequestBody Doctor doc) {
        doctorService.insertDoctor(doc);
    }


}
