package com.example.example1.model;

public class Doctor {
    private String Name;
    private int PatientID;
    private int Age;
    private String Address;
    private String Gender;
    private String PhoneNumber;

    public Doctor(String name, int patientID, int age, String address, String gender, String phoneNumber) {
        Name = name;
        PatientID = patientID;
        Age = age;
        Address = address;
        Gender = gender;
        PhoneNumber = phoneNumber;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public Doctor() {
    }



    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getPatientID() {
        return PatientID;
    }

    public void setPatientID(int patientID) {
        PatientID = patientID;
    }

    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = age;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }
}